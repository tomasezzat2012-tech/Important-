# مفكرة المحامي — خطوات التشغيل

> الكود ماتبناش عندي (مفيش Android SDK). أول Build هيحصل على GitHub. لو فشل ابعتلي نص الخطأ.

## 1) Firebase (console.firebase.google.com)
1. **Add project** (اسم أي حاجة، وممكن تقفل Google Analytics).
2. **Add app ← Android**، الـ Package name بالظبط: `com.lawyerdiary.app`
3. خانة **SHA-1** الصق:
   `76:6E:B2:D9:85:79:78:D3:41:71:30:21:12:8E:5A:35:CC:60:8D:6D`
   (لو نسيتها: Project settings ← تطبيقك ← Add fingerprint.)
4. **Build ← Authentication ← Get started ← Sign-in method**: فعّل **Email/Password** و **Google**.
5. **نزّل google-services.json بعد تفعيل Google** (Project settings ← Your apps ← google-services.json). لو نزلته قبل التفعيل نزّله تاني.
6. **Build ← Firestore Database ← Create database** (Production mode).
7. تبويب **Rules**: الصق محتوى `firebase/firestore.rules` ← **Publish**.

## 2) GitHub (3 حاجات بس هتترفع)
1. اعمل Repository جديد (Public).
2. **Add file ← Upload files**: ارفع **ملف الـ ZIP نفسه** `LawyerDiary-Android-Source.zip` من غير ما تفكه + ملف **google-services.json** (أي اسم يبدأ بـ google-services يشتغل). **Commit**.
3. **Add file ← Create new file**: في خانة الاسم اكتب `.github/workflows/build-apk.yml` والصق محتوى ملف `build-apk.yml` المرفق. **Commit**.
4. **Settings ← Actions ← General ← Workflow permissions ← Read and write ← Save**.
5. **Actions ← Build APK ← Run workflow**، واستنى 5–8 دقايق.
6. من **Releases** نزّل `LawyerDiary.apk` وثبّته على موبايلك (اسمح بالتثبيت من مصدر غير معروف).

## 3) قبل ما تسلّمه للمحامي — جرّب على موبايل حقيقي
- [ ] إنشاء حساب (اسم + تليفون + جيميل + باسورد)
- [ ] الدخول بجوجل (ويطلب التليفون لأول مرة)
- [ ] إضافة جلسة، وتظهر في التقويم بنقطة ذهبية
- [ ] المنبه والاستيقاظ بيرنوا في الوقت (جرّب جلسة بعد 5 دقايق)
- [ ] تأجيل (الموعد الجديد يظهر والمنبهات تتحرك) وإلغاء (المنبهات تقف) واسترجاع
- [ ] بعد ريستارت الموبايل المنبهات لسه شغالة

## ملاحظات مهمة
- لازم المحامي يعمل من إعدادات الموبايل: البطارية ← مفكرة المحامي ← «بدون قيود»، وإلا بعض الموبايلات (شاومي/أوبو/سامسونج) ممكن توقف المنبه. التطبيق نفسه بيكتب الخطوة دي في صفحة «حسابي».
- الـ keystore وباسورده (`lawyer123456`) جوه المشروع لتوقيع ثابت. ماتستخدمهوش لنشر على Google Play.
- بيانات كل محامي منفصلة وخاصة بيه (الـ rules بتمنع أي حد تاني).
