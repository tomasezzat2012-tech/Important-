package com.lawyerdiary.app

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.KeyboardArrowLeft
import androidx.compose.material.icons.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.delay
import java.util.Calendar

/* ------------------------------------------------------------ pickers */

fun pickDate(ctx: Context, initial: Long, onPick: (Long) -> Unit) {
    try {
        val c = cal(initial)
        DatePickerDialog(ctx, { _, y, m, d ->
            val r = cal(initial); r.set(y, m, d); onPick(r.timeInMillis)
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
    } catch (_: Throwable) { }
}

fun pickTime(ctx: Context, initial: Long, onPick: (Long) -> Unit) {
    try {
        val c = cal(initial)
        TimePickerDialog(ctx, { _, h, mi ->
            val r = cal(initial)
            r.set(Calendar.HOUR_OF_DAY, h); r.set(Calendar.MINUTE, mi); r.set(Calendar.SECOND, 0); r.set(Calendar.MILLISECOND, 0)
            onPick(r.timeInMillis)
        }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), false).show()
    } catch (_: Throwable) { }
}

private fun openUri(ctx: Context, action: String, uri: String) {
    try { ctx.startActivity(Intent(action, Uri.parse(uri)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Throwable) { }
}

/* ------------------------------------------------------------ main */

private class Editor(val session: Session?, val dateMs: Long)

class SessionActions(
    val onEdit: (Session) -> Unit,
    val onPostpone: (Session) -> Unit,
    val onCancel: (Session) -> Unit,
    val onRestore: (Session) -> Unit,
    val onDelete: (Session) -> Unit
)

@Composable
fun MainScreen(user: FirebaseUser, profile: Map<String, Any>) {
    val ctx = LocalContext.current
    var sessions by remember { mutableStateOf<List<Session>>(emptyList()) }
    var tab by remember { mutableStateOf(0) }
    var editor by remember { mutableStateOf<Editor?>(null) }
    var postponing by remember { mutableStateOf<Session?>(null) }
    var deleting by remember { mutableStateOf<Session?>(null) }
    var selected by remember { mutableStateOf(dayStart(System.currentTimeMillis())) }

    DisposableEffect(user.uid) {
        val reg = Repo.sessions(user.uid).addSnapshotListener { s, _ ->
            try {
                sessions = (s?.documents?.mapNotNull { try { it.toSession() } catch (_: Throwable) { null } } ?: emptyList()).sortedBy { it.at }
            } catch (_: Throwable) { }
        }
        onDispose { reg.remove() }
    }
    LaunchedEffect(sessions) { Alarms.sync(ctx, sessions) }

    fun save(s: Session) { Repo.saveSession(user.uid, s) }

    postponing?.let { s ->
        PostponeDialog(s, onDismiss = { postponing = null }) { newAt ->
            val gap = s.at - s.wakeAt
            save(s.copy(at = newAt, wakeAt = newAt - gap, status = ST_POSTPONED, postponedFrom = s.at))
            postponing = null
        }
    }
    deleting?.let { s ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("حذف الجلسة؟") },
            text = { Text("هتتحذف نهائياً وتتلغي منبهاتها.") },
            confirmButton = { TextButton(onClick = { Repo.deleteSession(user.uid, s.id); deleting = null }) { Text("حذف", color = StRed) } },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("رجوع") } }
        )
    }

    val actions = SessionActions(
        onEdit = { editor = Editor(it, it.at) },
        onPostpone = { postponing = it },
        onCancel = { save(it.copy(status = ST_CANCELLED)) },
        onRestore = { save(it.copy(status = ST_SCHEDULED)) },
        onDelete = { deleting = it }
    )

    val ed = editor
    if (ed != null) {
        BackHandler { editor = null }
        EditorScreen(ed.session, ed.dateMs, onBack = { editor = null }) { s -> save(s); editor = null }
    } else {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            floatingActionButton = {
                if (tab != 2) {
                    FloatingActionButton(
                        onClick = { editor = Editor(null, if (tab == 0) selected else System.currentTimeMillis()) },
                        containerColor = MaterialTheme.colorScheme.primary,
                        contentColor = MaterialTheme.colorScheme.onPrimary
                    ) { Icon(Icons.Filled.Add, "إضافة جلسة") }
                }
            },
            bottomBar = {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                    val items: List<Pair<String, ImageVector>> = listOf(
                        "التقويم" to Icons.Filled.DateRange,
                        "الجلسات" to Icons.Filled.Notifications,
                        "الإعدادات" to Icons.Filled.Settings
                    )
                    items.forEachIndexed { i, it ->
                        NavigationBarItem(selected = tab == i, onClick = { tab = i },
                            icon = { Icon(it.second, it.first) }, label = { Text(it.first, fontSize = 11.sp) })
                    }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (tab) {
                    0 -> CalendarTab(sessions, selected, { selected = it }, actions)
                    1 -> SessionsTab(sessions, actions)
                    else -> SettingsTab(profile, user)
                }
            }
        }
    }
}

/* ------------------------------------------------------------ calendar */

@Composable
private fun CalendarTab(sessions: List<Session>, selected: Long, onSelect: (Long) -> Unit, actions: SessionActions) {
    var month by remember { mutableStateOf(dayStart(System.currentTimeMillis())) }
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { delay(30_000); now = System.currentTimeMillis() } }

    val today = dayStart(now)
    val byDay = sessions.groupBy { dayStart(it.at) }
    val active = sessions.filter { it.status != ST_CANCELLED }
    val next = active.firstOrNull { it.at >= now }
    val todayCount = active.count { dayStart(it.at) == today }
    val weekCount = active.count { it.at >= now && it.at < now + 7 * 86_400_000L }

    val first = cal(month).apply { set(Calendar.DAY_OF_MONTH, 1) }
    val offset = first.get(Calendar.DAY_OF_WEEK) % 7 // السبت = 0
    val daysInMonth = first.getActualMaximum(Calendar.DAY_OF_MONTH)
    val cells = ArrayList<Long?>()
    repeat(offset) { cells.add(null) }
    for (d in 1..daysInMonth) cells.add(dayStart(cal(first.timeInMillis).apply { set(Calendar.DAY_OF_MONTH, d) }.timeInMillis))
    while (cells.size % 7 != 0) cells.add(null)
    val cs = MaterialTheme.colorScheme

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Logo(40.dp)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("مفكرة المحامي", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text(Fmt.date(now), fontSize = 12.sp, color = cs.onSurfaceVariant)
                }
            }
        }
        item {
            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(cs.primary).padding(16.dp)
            ) {
                if (next != null) {
                    Text("الجلسة القادمة • ${relTime(next.at, now)}", color = cs.onPrimary.copy(alpha = 0.85f), fontSize = 12.sp)
                    Text(next.title, color = cs.onPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("${Fmt.shortDate(next.at)} • ${Fmt.time(next.at)}", color = cs.onPrimary.copy(alpha = 0.9f), fontSize = 13.sp)
                } else {
                    Text("مفيش جلسات قادمة", color = cs.onPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                    Text("اليوم: $todayCount", color = cs.onPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Text("الأسبوع: $weekCount", color = cs.onPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { month = cal(month).apply { add(Calendar.MONTH, -1) }.timeInMillis }) { Icon(Icons.Filled.KeyboardArrowRight, "السابق") }
                Text(
                    Fmt.month(month), Modifier.weight(1f).clickable { month = today; onSelect(today) },
                    textAlign = TextAlign.Center, fontSize = 18.sp, fontWeight = FontWeight.Bold
                )
                IconButton(onClick = { month = cal(month).apply { add(Calendar.MONTH, 1) }.timeInMillis }) { Icon(Icons.Filled.KeyboardArrowLeft, "التالي") }
            }
            Row(Modifier.fillMaxWidth()) {
                listOf("س", "ح", "ن", "ث", "ر", "خ", "ج").forEach {
                    Text(it, Modifier.weight(1f), textAlign = TextAlign.Center, color = cs.onSurfaceVariant, fontSize = 12.sp)
                }
            }
        }
        items(cells.chunked(7)) { week ->
            Row(Modifier.fillMaxWidth()) {
                week.forEach { d ->
                    Box(Modifier.weight(1f).aspectRatio(1f).padding(2.dp), Alignment.Center) {
                        if (d != null) {
                            val list = byDay[d] ?: emptyList()
                            val isSel = d == selected
                            Column(
                                Modifier.fillMaxSize().clip(RoundedCornerShape(12.dp))
                                    .background(if (isSel) cs.primary else cs.surface)
                                    .border(1.dp, if (d == today && !isSel) cs.primary else cs.outline, RoundedCornerShape(12.dp))
                                    .clickable { onSelect(d) },
                                Arrangement.Center, Alignment.CenterHorizontally
                            ) {
                                Text(
                                    "${cal(d).get(Calendar.DAY_OF_MONTH)}", fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                                    color = if (isSel) cs.onPrimary else cs.onSurface
                                )
                                if (list.isNotEmpty()) {
                                    val any = list.any { it.status != ST_CANCELLED }
                                    Box(
                                        Modifier.padding(top = 2.dp).size(6.dp).clip(CircleShape)
                                            .background(if (isSel) cs.onPrimary else if (any) cs.primary else cs.outline)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
        item { Text(Fmt.date(selected), fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp)) }
        val dayList = byDay[selected] ?: emptyList()
        if (dayList.isEmpty()) item { Text("مفيش جلسات في اليوم ده", color = cs.onSurfaceVariant, fontSize = 13.sp) }
        items(dayList) { SessionCard(it, actions) }
        item { Spacer(Modifier.height(90.dp)) }
    }
}

/* ------------------------------------------------------------ sessions list */

@Composable
private fun SessionsTab(sessions: List<Session>, actions: SessionActions) {
    var filter by remember { mutableStateOf(0) } // 0 قادمة، 1 سابقة، 2 ملغاة
    var q by remember { mutableStateOf("") }
    val now = System.currentTimeMillis()
    val base = when (filter) {
        0 -> sessions.filter { it.at >= now && it.status != ST_CANCELLED }
        1 -> sessions.filter { it.at < now && it.status != ST_CANCELLED }.reversed()
        else -> sessions.filter { it.status == ST_CANCELLED }
    }
    val list = if (q.isBlank()) base else base.filter {
        listOf(it.title, it.caseNo, it.court, it.type, it.notes).any { f -> f.contains(q.trim(), ignoreCase = true) }
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            q, { q = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = { Text("بحث: موكل، قضية، محكمة") },
            leadingIcon = { Icon(Icons.Filled.Search, null) }
        )
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("القادمة", "السابقة", "الملغاة").forEachIndexed { i, t -> ChipBtn(t, filter == i) { filter = i } }
        }
        Spacer(Modifier.height(8.dp))
        if (list.isEmpty()) Text("مفيش نتائج", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
        LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(list) { s ->
                Text(Fmt.date(s.at), fontSize = 12.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                SessionCard(s, actions)
            }
            item { Spacer(Modifier.height(90.dp)) }
        }
    }
}

@Composable
private fun SessionCard(s: Session, a: SessionActions) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val cancelled = s.status == ST_CANCELLED
    val muted = if (cancelled) cs.onSurfaceVariant else cs.onSurface
    AppCard(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(s.title, Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 16.sp, color = muted)
            if (s.type.isNotBlank()) { Pill(s.type, cs.primary); Spacer(Modifier.width(6.dp)) }
            Pill(statusLabel(s.status), statusColor(s.status))
        }
        Spacer(Modifier.height(6.dp))
        Text("${Fmt.time(s.at)}  •  ${Fmt.shortDate(s.at)}", color = muted, fontSize = 14.sp)
        if (s.alarmOn && !cancelled) Text("استيقاظ ${Fmt.time(s.wakeAt)}  •  تنبيه قبلها ${s.remindMin} د", fontSize = 12.sp, color = cs.onSurfaceVariant)
        val line = listOf(
            if (s.caseNo.isNotBlank()) "قضية ${s.caseNo}" else "",
            s.court
        ).filter { it.isNotBlank() }.joinToString("  •  ")
        if (line.isNotBlank()) Text(line, fontSize = 12.sp, color = cs.onSurfaceVariant)
        if (s.notes.isNotBlank()) Text(s.notes, fontSize = 12.sp, color = cs.onSurfaceVariant)
        if (s.postponedFrom > 0) Text("أُجلت من ${Fmt.shortDate(s.postponedFrom)}", fontSize = 12.sp, color = StAmber)
        Spacer(Modifier.height(6.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.CenterVertically) {
            if (cancelled) TextButton(onClick = { a.onRestore(s) }) { Text("استرجاع", color = StGreen) }
            else {
                TextButton(onClick = { a.onPostpone(s) }) { Text("تأجيل", color = StAmber) }
                TextButton(onClick = { a.onCancel(s) }) { Text("إلغاء", color = StRed) }
            }
            TextButton(onClick = { a.onEdit(s) }) { Text("تعديل") }
            TextButton(onClick = { a.onDelete(s) }) { Text("حذف", color = cs.onSurfaceVariant) }
            if (s.clientPhone.isNotBlank()) {
                IconButton(onClick = { openUri(ctx, Intent.ACTION_DIAL, "tel:${s.clientPhone}") }) { Icon(Icons.Filled.Call, "اتصال", tint = cs.primary) }
                TextButton(onClick = { openUri(ctx, Intent.ACTION_VIEW, "https://wa.me/${waNumber(s.clientPhone)}") }) { Text("واتساب", color = StGreen) }
            }
        }
    }
}

@Composable
private fun PostponeDialog(s: Session, onDismiss: () -> Unit, onConfirm: (Long) -> Unit) {
    val ctx = LocalContext.current
    var at by remember { mutableStateOf(maxOf(s.at, System.currentTimeMillis()) + 7 * 86_400_000L) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تأجيل الجلسة") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("الموعد الحالي: ${Fmt.shortDate(s.at)} ${Fmt.time(s.at)}", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedButton(onClick = { pickDate(ctx, at) { at = withTime(it, at) } }, Modifier.fillMaxWidth()) { Text("التاريخ: ${Fmt.shortDate(at)}") }
                OutlinedButton(onClick = { pickTime(ctx, at) { at = it } }, Modifier.fillMaxWidth()) { Text("الوقت: ${Fmt.time(at)}") }
            }
        },
        confirmButton = { TextButton(onClick = { onConfirm(at) }) { Text("تأكيد", color = StAmber) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("رجوع") } }
    )
}

/* ------------------------------------------------------------ editor */

@Composable
private fun EditorScreen(old: Session?, dateMs: Long, onBack: () -> Unit, onSave: (Session) -> Unit) {
    val ctx = LocalContext.current
    val st = LocalSettings.current
    val base = remember {
        old?.at ?: cal(dateMs).apply { set(Calendar.HOUR_OF_DAY, 10); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
    }
    var title by remember { mutableStateOf(old?.title ?: "") }
    var type by remember { mutableStateOf(old?.type ?: "") }
    var caseNo by remember { mutableStateOf(old?.caseNo ?: "") }
    var court by remember { mutableStateOf(old?.court ?: "") }
    var phone by remember { mutableStateOf(old?.clientPhone ?: "") }
    var notes by remember { mutableStateOf(old?.notes ?: "") }
    var at by remember { mutableStateOf(base) }
    var wake by remember { mutableStateOf(old?.wakeAt ?: (base - st.wakeHours * 3_600_000L)) }
    var remind by remember { mutableStateOf(old?.remindMin ?: st.remind) }
    var alarmOn by remember { mutableStateOf(old?.alarmOn ?: true) }
    var error by remember { mutableStateOf<String?>(null) }
    val cs = MaterialTheme.colorScheme

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "رجوع") }
            Text(if (old == null) "جلسة جديدة" else "تعديل الجلسة", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }
        OutlinedTextField(title, { title = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("اسم الموكل / القضية *") })
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            SESSION_TYPES.forEach { t -> ChipBtn(t, type == t) { type = if (type == t) "" else t } }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(caseNo, { caseNo = it }, Modifier.weight(1f), singleLine = true, label = { Text("رقم القضية") })
            OutlinedTextField(court, { court = it }, Modifier.weight(1f), singleLine = true, label = { Text("المحكمة") })
        }
        OutlinedTextField(
            phone, { phone = it.filter { c -> c.isDigit() || c == '+' } }, Modifier.fillMaxWidth(), singleLine = true,
            label = { Text("تليفون الموكل (اختياري)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { pickDate(ctx, at) { d -> at = withTime(d, at); wake = withTime(d, wake) } }, Modifier.weight(1f)) { Text(Fmt.shortDate(at), fontSize = 13.sp) }
            OutlinedButton(onClick = { pickTime(ctx, at) { at = it } }, Modifier.weight(1f)) { Text(Fmt.time(at), fontSize = 13.sp) }
        }
        AppCard(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("المنبه", Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                Switch(alarmOn, { alarmOn = it })
            }
            if (alarmOn) {
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = { pickTime(ctx, wake) { wake = withTime(at, it) } }, Modifier.fillMaxWidth()) { Text("وقت الاستيقاظ: ${Fmt.time(wake)}") }
                Spacer(Modifier.height(8.dp))
                Text("تنبيه قبل الجلسة", fontSize = 12.sp, color = cs.onSurfaceVariant)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(15, 30, 60, 90, 120, 180).forEach { m -> ChipBtn("$m د", remind == m) { remind = m } }
                }
            }
        }
        OutlinedTextField(notes, { notes = it }, Modifier.fillMaxWidth().height(100.dp), label = { Text("ملاحظات") })
        error?.let { Text(it, color = cs.error, fontSize = 13.sp) }
        Button(
            onClick = {
                val w = withTime(at, wake)
                when {
                    title.isBlank() -> error = "اكتب اسم الموكل أو القضية."
                    alarmOn && w >= at -> error = "وقت الاستيقاظ لازم يكون قبل الجلسة."
                    else -> onSave(
                        (old ?: Session()).copy(
                            title = title.trim(), type = type, caseNo = caseNo.trim(), court = court.trim(),
                            clientPhone = phone, notes = notes.trim(),
                            at = at, wakeAt = w, remindMin = remind, alarmOn = alarmOn,
                            status = if (old?.status == ST_CANCELLED) ST_SCHEDULED else (old?.status ?: ST_SCHEDULED)
                        )
                    )
                }
            },
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text("حفظ", fontSize = 16.sp) }
        Spacer(Modifier.height(24.dp))
    }
}

/* ------------------------------------------------------------ settings */

@Composable
private fun SettingsTab(profile: Map<String, Any>, user: FirebaseUser) {
    val st = LocalSettings.current
    val cs = MaterialTheme.colorScheme
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Spacer(Modifier.height(4.dp))
        Text("الإعدادات", fontSize = 22.sp, fontWeight = FontWeight.Bold)

        AppCard(Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Logo(48.dp)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(profile["name"] as? String ?: "", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text("${profile["phone"] ?: ""}", fontSize = 13.sp, color = cs.onSurfaceVariant)
                    Text("${profile["email"] ?: user.email ?: ""}", fontSize = 13.sp, color = cs.onSurfaceVariant)
                }
            }
        }

        AppCard(Modifier.fillMaxWidth()) {
            Text("المظهر", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("تلقائي", "فاتح", "داكن").forEachIndexed { i, t -> ChipBtn(t, st.mode == i) { st.setMode(i) } }
            }
            Spacer(Modifier.height(12.dp))
            Text("اللون", fontSize = 13.sp, color = cs.onSurfaceVariant)
            Spacer(Modifier.height(6.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ACCENTS.forEachIndexed { i, a ->
                    Box(
                        Modifier.size(38.dp).clip(CircleShape).background(a.second)
                            .border(if (st.accent == i) 3.dp else 0.dp, if (st.accent == i) cs.onSurface else Color.Transparent, CircleShape)
                            .clickable { st.setAccent(i) }
                    )
                }
            }
            Text(ACCENTS[st.accent.coerceIn(0, ACCENTS.size - 1)].first, fontSize = 12.sp, color = cs.onSurfaceVariant, modifier = Modifier.padding(top = 6.dp))
        }

        AppCard(Modifier.fillMaxWidth()) {
            Text("افتراضي الجلسات الجديدة", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Text("الاستيقاظ قبل الجلسة بـ", fontSize = 13.sp, color = cs.onSurfaceVariant)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(1, 2, 3, 4, 5).forEach { h -> ChipBtn("$h ساعة", st.wakeHours == h) { st.setWakeHours(h) } }
            }
            Spacer(Modifier.height(10.dp))
            Text("تنبيه قبل الجلسة بـ", fontSize = 13.sp, color = cs.onSurfaceVariant)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(15, 30, 60, 120).forEach { m -> ChipBtn("$m د", st.remind == m) { st.setRemind(m) } }
            }
        }

        AppCard(Modifier.fillMaxWidth()) {
            Text("عشان المنبه يرن دايماً", fontWeight = FontWeight.Bold)
            Text(
                "إعدادات الموبايل ← البطارية ← مفكرة المحامي ← بدون قيود، واسمح بالإشعارات.",
                fontSize = 12.sp, color = cs.onSurfaceVariant
            )
        }
        OutlinedButton(onClick = { Repo.auth.signOut() }, Modifier.fillMaxWidth().height(50.dp)) { Text("تسجيل الخروج") }
        Spacer(Modifier.height(90.dp))
    }
}
