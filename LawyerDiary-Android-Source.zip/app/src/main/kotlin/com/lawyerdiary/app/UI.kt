package com.lawyerdiary.app

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.Calendar

private val Red = Color(0xFFB3261E)
private val Green = Color(0xFF2E7D32)
private val Amber = Color(0xFFB26A00)

/* ------------------------------------------------------------ pickers */

fun pickDate(ctx: Context, initial: Long, onPick: (Long) -> Unit) {
    val c = cal(initial)
    DatePickerDialog(ctx, { _, y, m, d ->
        val r = cal(initial); r.set(y, m, d); onPick(r.timeInMillis)
    }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
}

fun pickTime(ctx: Context, initial: Long, onPick: (Long) -> Unit) {
    val c = cal(initial)
    TimePickerDialog(ctx, { _, h, mi ->
        val r = cal(initial)
        r.set(Calendar.HOUR_OF_DAY, h); r.set(Calendar.MINUTE, mi); r.set(Calendar.SECOND, 0); r.set(Calendar.MILLISECOND, 0)
        onPick(r.timeInMillis)
    }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), false).show()
}

/* ------------------------------------------------------------ root */

@Composable
fun AppRoot() {
    var user by remember { mutableStateOf(Repo.auth.currentUser) }
    DisposableEffect(Unit) {
        val l = FirebaseAuth.AuthStateListener { user = it.currentUser }
        Repo.auth.addAuthStateListener(l)
        onDispose { Repo.auth.removeAuthStateListener(l) }
    }
    val u = user
    if (u == null) AuthScreen() else ProfileGate(u)
}

@Composable
private fun ProfileGate(user: FirebaseUser) {
    var loaded by remember(user.uid) { mutableStateOf(false) }
    var profile by remember(user.uid) { mutableStateOf<Map<String, Any>?>(null) }
    var loadError by remember(user.uid) { mutableStateOf<String?>(null) }
    DisposableEffect(user.uid) {
        val reg = Repo.db.collection("users").document(user.uid).addSnapshotListener { s, e ->
            if (e != null) { loadError = e.message; loaded = true; return@addSnapshotListener }
            profile = s?.data
            loaded = true
        }
        onDispose { reg.remove() }
    }
    val p = profile
    when {
        !loaded -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
        loadError != null && p == null -> Column(
            Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally
        ) {
            Text("تعذر تحميل الحساب.\n$loadError", textAlign = TextAlign.Center)
            Spacer(Modifier.height(12.dp))
            Button(onClick = { Repo.auth.signOut() }) { Text("تسجيل الخروج") }
        }
        p == null -> CompleteProfileScreen(user)
        else -> MainScreen(user, p)
    }
}

/* ------------------------------------------------------------ auth */

@Composable
private fun Logo() {
    Box(
        Modifier.size(88.dp).clip(RoundedCornerShape(22.dp)).background(Navy),
        Alignment.Center
    ) { Text("⚖", color = Gold, fontSize = 48.sp) }
}

@Composable
fun AuthScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var register by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    val googleLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        try {
            val acc = GoogleSignIn.getSignedInAccountFromIntent(res.data).getResult(ApiException::class.java)
            val cred = GoogleAuthProvider.getCredential(acc.idToken, null)
            scope.launch {
                busy = true
                try { Repo.auth.signInWithCredential(cred).await() } catch (e: Exception) { error = e.message }
                busy = false
            }
        } catch (e: ApiException) {
            error = "فشل الدخول بجوجل (كود ${e.statusCode}). تأكد من إضافة SHA-1 في Firebase."
        }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        Arrangement.Center, Alignment.CenterHorizontally
    ) {
        Logo()
        Spacer(Modifier.height(12.dp))
        Text("مفكرة المحامي", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Navy)
        Text(if (register) "إنشاء حساب جديد" else "تسجيل الدخول", color = Color.Gray)
        Spacer(Modifier.height(20.dp))

        if (register) {
            OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("الاسم") })
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                phone, { phone = it.filter { c -> c.isDigit() || c == '+' } }, Modifier.fillMaxWidth(), singleLine = true,
                label = { Text("رقم التليفون") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
            )
            Spacer(Modifier.height(10.dp))
        }
        OutlinedTextField(
            email, { email = it.trim() }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("الجيميل") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
        )
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            pass, { pass = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("كلمة المرور (6 أحرف أو أكتر)") },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
        )
        error?.let { Spacer(Modifier.height(8.dp)); Text(it, color = Red, fontSize = 13.sp) }
        Spacer(Modifier.height(14.dp))
        Button(
            onClick = {
                error = null
                if (email.isBlank() || pass.length < 6) { error = "اكتب جيميل صحيح وكلمة مرور 6 أحرف على الأقل."; return@Button }
                if (register && (name.isBlank() || phone.length < 10)) { error = "اكتب الاسم ورقم تليفون صحيح."; return@Button }
                scope.launch {
                    busy = true
                    try {
                        if (register) {
                            val r = Repo.auth.createUserWithEmailAndPassword(email, pass).await()
                            val uid = r.user?.uid
                            if (uid != null) Repo.saveProfile(uid, name.trim(), phone, email)
                        } else {
                            Repo.auth.signInWithEmailAndPassword(email, pass).await()
                        }
                    } catch (e: Exception) { error = e.message }
                    busy = false
                }
            },
            enabled = !busy, modifier = Modifier.fillMaxWidth().height(50.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Navy)
        ) { Text(if (register) "إنشاء الحساب" else "دخول") }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(
            onClick = {
                error = null
                val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                    .requestIdToken(ctx.getString(R.string.default_web_client_id)).requestEmail().build()
                val client = GoogleSignIn.getClient(ctx, gso)
                client.signOut().addOnCompleteListener { googleLauncher.launch(client.signInIntent) }
            },
            enabled = !busy, modifier = Modifier.fillMaxWidth().height(50.dp)
        ) { Text("الدخول بحساب جوجل") }
        TextButton(onClick = { register = !register; error = null }) {
            Text(if (register) "عندي حساب بالفعل" else "مستخدم جديد؟ أنشئ حساب")
        }
    }
}

@Composable
private fun CompleteProfileScreen(user: FirebaseUser) {
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf(user.displayName ?: "") }
    var phone by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Text("خطوة أخيرة", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Navy)
        Text("كمّل بياناتك", color = Color.Gray)
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("الاسم") })
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            phone, { phone = it.filter { c -> c.isDigit() || c == '+' } }, Modifier.fillMaxWidth(), singleLine = true,
            label = { Text("رقم التليفون") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
        )
        error?.let { Spacer(Modifier.height(8.dp)); Text(it, color = Red, fontSize = 13.sp) }
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = {
                if (name.isBlank() || phone.length < 10) { error = "اكتب الاسم ورقم تليفون صحيح."; return@Button }
                scope.launch {
                    busy = true
                    try { Repo.saveProfile(user.uid, name.trim(), phone, user.email ?: "") }
                    catch (e: Exception) { error = e.message }
                    busy = false
                }
            },
            enabled = !busy, modifier = Modifier.fillMaxWidth().height(50.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Navy)
        ) { Text("حفظ ومتابعة") }
        TextButton(onClick = { Repo.auth.signOut() }) { Text("تسجيل الخروج") }
    }
}

/* ------------------------------------------------------------ main */

private class Editor(val session: Session?, val dateMs: Long)

@Composable
private fun MainScreen(user: FirebaseUser, profile: Map<String, Any>) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var sessions by remember { mutableStateOf<List<Session>>(emptyList()) }
    var tab by remember { mutableStateOf(0) }
    var editor by remember { mutableStateOf<Editor?>(null) }
    var postponing by remember { mutableStateOf<Session?>(null) }
    var deleting by remember { mutableStateOf<Session?>(null) }

    DisposableEffect(user.uid) {
        val reg = Repo.sessions(user.uid).addSnapshotListener { s, _ ->
            sessions = (s?.documents?.mapNotNull { it.toSession() } ?: emptyList()).sortedBy { it.at }
        }
        onDispose { reg.remove() }
    }
    LaunchedEffect(sessions) { Alarms.sync(ctx, sessions) }

    fun save(s: Session) { scope.launch { try { Repo.saveSession(user.uid, s) } catch (_: Exception) { } } }

    val ed = editor
    if (ed != null) {
        BackHandler { editor = null }
        EditorScreen(ed.session, ed.dateMs, onBack = { editor = null }) { s -> save(s); editor = null }
        return
    }

    postponing?.let { s ->
        PostponeDialog(s, onDismiss = { postponing = null }) { newAt ->
            val gap = s.at - s.wakeAt
            save(s.copy(at = newAt, wakeAt = newAt - gap, status = ST_POSTPONED, postponedFrom = s.at))
            postponing = null
        }
    }
    deleting?.let { s ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("حذف الجلسة؟") },
            text = { Text("هتتحذف الجلسة نهائياً وتتلغي منبهاتها.") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch { try { Repo.deleteSession(user.uid, s.id) } catch (_: Exception) { } }
                    deleting = null
                }) { Text("حذف", color = Red) }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("رجوع") } }
        )
    }

    val actions = SessionActions(
        onEdit = { editor = Editor(it, it.at) },
        onPostpone = { postponing = it },
        onCancel = { save(it.copy(status = ST_CANCELLED)) },
        onRestore = { save(it.copy(status = ST_SCHEDULED)) },
        onDelete = { deleting = it }
    )

    Scaffold(
        containerColor = Paper,
        floatingActionButton = {
            if (tab == 0) {
                // يتحدد التاريخ من التقويم عبر زر "إضافة" داخل الشاشة؛ هذا الزر بيضيف جلسة لليوم
                FloatingActionButton(onClick = { editor = Editor(null, System.currentTimeMillis()) }, containerColor = Gold, contentColor = Color.White) {
                    Text("+", fontSize = 28.sp)
                }
            }
        },
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                listOf("التقويم", "القادمة", "حسابي").forEachIndexed { i, t ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i },
                        icon = { Text(listOf("📅", "⏰", "👤")[i], fontSize = 20.sp) },
                        label = { Text(t, fontSize = 11.sp) })
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> CalendarTab(sessions, actions) { editor = Editor(null, it) }
                1 -> UpcomingTab(sessions, actions)
                else -> AccountTab(profile, user)
            }
        }
    }
}

class SessionActions(
    val onEdit: (Session) -> Unit,
    val onPostpone: (Session) -> Unit,
    val onCancel: (Session) -> Unit,
    val onRestore: (Session) -> Unit,
    val onDelete: (Session) -> Unit
)

/* ------------------------------------------------------------ calendar */

@Composable
private fun CalendarTab(sessions: List<Session>, actions: SessionActions, onAdd: (Long) -> Unit) {
    var month by remember { mutableStateOf(dayStart(System.currentTimeMillis())) }
    var selected by remember { mutableStateOf(dayStart(System.currentTimeMillis())) }
    val today = dayStart(System.currentTimeMillis())
    val byDay = sessions.groupBy { dayStart(it.at) }

    val first = cal(month).apply { set(Calendar.DAY_OF_MONTH, 1) }
    val offset = first.get(Calendar.DAY_OF_WEEK) % 7 // السبت = 0
    val daysInMonth = first.getActualMaximum(Calendar.DAY_OF_MONTH)
    val cells = ArrayList<Long?>()
    repeat(offset) { cells.add(null) }
    for (d in 1..daysInMonth) cells.add(cal(first.timeInMillis).apply { set(Calendar.DAY_OF_MONTH, d) }.timeInMillis.let { dayStart(it) })
    while (cells.size % 7 != 0) cells.add(null)

    LazyColumn(Modifier.fillMaxSize().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { month = cal(month).apply { add(Calendar.MONTH, -1) }.timeInMillis }) { Text("▶", fontSize = 20.sp, color = Navy) }
                Text(Fmt.month(month), Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Navy)
                TextButton(onClick = { month = cal(month).apply { add(Calendar.MONTH, 1) }.timeInMillis }) { Text("◀", fontSize = 20.sp, color = Navy) }
            }
            TextButton(onClick = { month = today; selected = today }, Modifier.fillMaxWidth()) { Text("اليوم", color = Gold) }
            Row(Modifier.fillMaxWidth()) {
                listOf("س", "ح", "ن", "ث", "ر", "خ", "ج").forEach {
                    Text(it, Modifier.weight(1f), textAlign = TextAlign.Center, color = Color.Gray, fontWeight = FontWeight.SemiBold)
                }
            }
        }
        items(cells.chunked(7)) { week ->
            Row(Modifier.fillMaxWidth()) {
                week.forEach { d ->
                    Box(Modifier.weight(1f).aspectRatio(1f).padding(2.dp), Alignment.Center) {
                        if (d != null) {
                            val list = byDay[d] ?: emptyList()
                            val isSel = d == selected
                            Column(
                                Modifier.fillMaxSize().clip(RoundedCornerShape(10.dp))
                                    .background(if (isSel) Navy else Color.White)
                                    .border(if (d == today) 2.dp else 0.dp, if (d == today) Gold else Color.Transparent, RoundedCornerShape(10.dp))
                                    .clickable { selected = d },
                                Arrangement.Center, Alignment.CenterHorizontally
                            ) {
                                Text("${cal(d).get(Calendar.DAY_OF_MONTH)}", color = if (isSel) Color.White else Navy, fontWeight = FontWeight.SemiBold)
                                if (list.isNotEmpty()) {
                                    val active = list.any { it.status != ST_CANCELLED }
                                    Box(Modifier.padding(top = 2.dp).size(6.dp).clip(CircleShape).background(if (active) Gold else Color.Gray))
                                }
                            }
                        }
                    }
                }
            }
        }
        item {
            Spacer(Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(Fmt.date(selected), Modifier.weight(1f), fontWeight = FontWeight.Bold, color = Navy)
                Button(onClick = { onAdd(selected) }, colors = ButtonDefaults.buttonColors(containerColor = Gold)) { Text("+ جلسة") }
            }
        }
        val dayList = byDay[selected] ?: emptyList()
        if (dayList.isEmpty()) item { Text("مفيش جلسات في اليوم ده.", color = Color.Gray, modifier = Modifier.padding(8.dp)) }
        items(dayList) { SessionCard(it, actions) }
        item { Spacer(Modifier.height(80.dp)) }
    }
}

@Composable
private fun UpcomingTab(sessions: List<Session>, actions: SessionActions) {
    val now = System.currentTimeMillis()
    val list = sessions.filter { it.at >= now && it.status != ST_CANCELLED }.take(40)
    Column(Modifier.fillMaxSize()) {
        Text("الجلسات القادمة", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Navy, modifier = Modifier.padding(16.dp))
        if (list.isEmpty()) Text("مفيش جلسات قادمة.", color = Color.Gray, modifier = Modifier.padding(16.dp))
        LazyColumn(Modifier.fillMaxSize().padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(list) { s ->
                Text(Fmt.date(s.at), color = Gold, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                SessionCard(s, actions)
            }
            item { Spacer(Modifier.height(16.dp)) }
        }
    }
}

@Composable
private fun SessionCard(s: Session, a: SessionActions) {
    val cancelled = s.status == ST_CANCELLED
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(s.title, Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 17.sp, color = if (cancelled) Color.Gray else Navy)
                Text(
                    statusLabel(s.status), fontSize = 12.sp, color = Color.White,
                    modifier = Modifier.clip(RoundedCornerShape(8.dp))
                        .background(when (s.status) { ST_CANCELLED -> Red; ST_POSTPONED -> Amber; else -> Green })
                        .padding(horizontal = 10.dp, vertical = 3.dp)
                )
            }
            Spacer(Modifier.height(6.dp))
            Text("🕘 الجلسة: ${Fmt.time(s.at)}", color = if (cancelled) Color.Gray else Color.Black)
            if (s.alarmOn) Text("⏰ الاستيقاظ: ${Fmt.time(s.wakeAt)}  •  تنبيه قبلها ${s.remindMin} دقيقة", fontSize = 13.sp, color = Color.DarkGray)
            else Text("🔕 المنبه مقفول", fontSize = 13.sp, color = Color.Gray)
            if (s.caseNo.isNotBlank()) Text("رقم القضية: ${s.caseNo}", fontSize = 13.sp, color = Color.DarkGray)
            if (s.court.isNotBlank()) Text("المحكمة: ${s.court}", fontSize = 13.sp, color = Color.DarkGray)
            if (s.notes.isNotBlank()) Text("ملاحظات: ${s.notes}", fontSize = 13.sp, color = Color.DarkGray)
            if (s.postponedFrom > 0) Text("أُجلت من ${Fmt.shortDate(s.postponedFrom)} ${Fmt.time(s.postponedFrom)}", fontSize = 12.sp, color = Amber)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                if (cancelled) {
                    TextButton(onClick = { a.onRestore(s) }) { Text("استرجاع", color = Green) }
                } else {
                    TextButton(onClick = { a.onPostpone(s) }) { Text("تأجيل", color = Amber) }
                    TextButton(onClick = { a.onCancel(s) }) { Text("إلغاء", color = Red) }
                }
                TextButton(onClick = { a.onEdit(s) }) { Text("تعديل") }
                TextButton(onClick = { a.onDelete(s) }) { Text("حذف", color = Color.Gray) }
            }
        }
    }
}

@Composable
private fun PostponeDialog(s: Session, onDismiss: () -> Unit, onConfirm: (Long) -> Unit) {
    val ctx = LocalContext.current
    var at by remember { mutableStateOf(maxOf(s.at, System.currentTimeMillis()) + 7 * 86_400_000L) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("تأجيل الجلسة") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("الموعد الحالي: ${Fmt.shortDate(s.at)} ${Fmt.time(s.at)}", fontSize = 13.sp, color = Color.Gray)
                OutlinedButton(onClick = { pickDate(ctx, at) { at = withTime(it, at) } }, Modifier.fillMaxWidth()) { Text("التاريخ الجديد: ${Fmt.shortDate(at)}") }
                OutlinedButton(onClick = { pickTime(ctx, at) { at = it } }, Modifier.fillMaxWidth()) { Text("وقت الجلسة: ${Fmt.time(at)}") }
                Text("وقت الاستيقاظ هيتحرك مع الموعد الجديد بنفس الفارق.", fontSize = 12.sp, color = Color.Gray)
            }
        },
        confirmButton = { TextButton(onClick = { onConfirm(at) }) { Text("تأكيد التأجيل", color = Amber) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("رجوع") } }
    )
}

/* ------------------------------------------------------------ editor */

@Composable
private fun EditorScreen(old: Session?, dateMs: Long, onBack: () -> Unit, onSave: (Session) -> Unit) {
    val ctx = LocalContext.current
    val base = remember {
        if (old != null) old.at else cal(dateMs).apply { set(Calendar.HOUR_OF_DAY, 10); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
    }
    var title by remember { mutableStateOf(old?.title ?: "") }
    var caseNo by remember { mutableStateOf(old?.caseNo ?: "") }
    var court by remember { mutableStateOf(old?.court ?: "") }
    var notes by remember { mutableStateOf(old?.notes ?: "") }
    var at by remember { mutableStateOf(base) }
    var wake by remember { mutableStateOf(old?.wakeAt ?: (base - 3 * 3_600_000L)) }
    var remind by remember { mutableStateOf(old?.remindMin ?: 60) }
    var alarmOn by remember { mutableStateOf(old?.alarmOn ?: true) }
    var menu by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("رجوع") }
            Text(if (old == null) "جلسة جديدة" else "تعديل الجلسة", Modifier.weight(1f), textAlign = TextAlign.Center, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Navy)
            Spacer(Modifier.width(64.dp))
        }
        OutlinedTextField(title, { title = it }, Modifier.fillMaxWidth(), label = { Text("اسم الموكل / القضية *") })
        OutlinedTextField(caseNo, { caseNo = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("رقم القضية") })
        OutlinedTextField(court, { court = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("المحكمة / الدائرة") })

        OutlinedButton(onClick = { pickDate(ctx, at) { d -> at = withTime(d, at); wake = withTime(d, wake) } }, Modifier.fillMaxWidth()) {
            Text("📅 تاريخ الجلسة: ${Fmt.date(at)}")
        }
        OutlinedButton(onClick = { pickTime(ctx, at) { at = it } }, Modifier.fillMaxWidth()) { Text("🕘 وقت الجلسة: ${Fmt.time(at)}") }

        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("تفعيل المنبه", Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
            Switch(alarmOn, { alarmOn = it })
        }
        if (alarmOn) {
            OutlinedButton(onClick = { pickTime(ctx, wake) { wake = withTime(at, it) } }, Modifier.fillMaxWidth()) { Text("⏰ وقت الاستيقاظ: ${Fmt.time(wake)}") }
            Box {
                OutlinedButton(onClick = { menu = true }, Modifier.fillMaxWidth()) { Text("🔔 تنبيه قبل الجلسة بـ $remind دقيقة") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    listOf(15, 30, 60, 90, 120, 180).forEach { m ->
                        DropdownMenuItem(text = { Text("$m دقيقة") }, onClick = { remind = m; menu = false })
                    }
                }
            }
        }
        OutlinedTextField(notes, { notes = it }, Modifier.fillMaxWidth().height(110.dp), label = { Text("ملاحظات (مستندات مطلوبة...)") })
        error?.let { Text(it, color = Red, fontSize = 13.sp) }
        Button(
            onClick = {
                val w = withTime(at, wake)
                when {
                    title.isBlank() -> error = "اكتب اسم الموكل أو القضية."
                    alarmOn && w >= at -> error = "وقت الاستيقاظ لازم يكون قبل وقت الجلسة."
                    else -> onSave(
                        (old ?: Session()).copy(
                            title = title.trim(), caseNo = caseNo.trim(), court = court.trim(), notes = notes.trim(),
                            at = at, wakeAt = w, remindMin = remind, alarmOn = alarmOn,
                            status = if (old?.status == ST_CANCELLED) ST_SCHEDULED else (old?.status ?: ST_SCHEDULED)
                        )
                    )
                }
            },
            modifier = Modifier.fillMaxWidth().height(52.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Navy)
        ) { Text("حفظ الجلسة") }
    }
}

/* ------------------------------------------------------------ account */

@Composable
private fun AccountTab(profile: Map<String, Any>, user: FirebaseUser) {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("حسابي", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Navy)
        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(profile["name"] as? String ?: "", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("📞 ${profile["phone"] ?: ""}")
                Text("✉ ${profile["email"] ?: user.email ?: ""}")
            }
        }
        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White)) {
            Column(Modifier.padding(16.dp)) {
                Text("للتأكد إن المنبه يرن", fontWeight = FontWeight.Bold)
                Text(
                    "• اسمح بالإشعارات للتطبيق.\n• من إعدادات الموبايل ← البطارية ← مفكرة المحامي ← اختار «بدون قيود».\n• متقفلش صوت المنبه (Alarm volume).",
                    fontSize = 13.sp, color = Color.DarkGray
                )
            }
        }
        Button(onClick = { Repo.auth.signOut() }, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Navy)) { Text("تسجيل الخروج") }
    }
}
