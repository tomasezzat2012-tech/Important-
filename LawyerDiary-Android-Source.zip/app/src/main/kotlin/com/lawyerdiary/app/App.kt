package com.lawyerdiary.app

import android.app.Application
import android.util.Log

/** يحفظ آخر خطأ في الجهاز عشان يتعرض في المرة الجاية ويتبعت للمطوّر. */
class App : Application() {
    override fun onCreate() {
        super.onCreate()
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                getSharedPreferences("crash", MODE_PRIVATE).edit()
                    .putString("last", Log.getStackTraceString(e).take(3500)).commit()
            } catch (_: Throwable) { }
            prev?.uncaughtException(t, e)
        }
    }
}
