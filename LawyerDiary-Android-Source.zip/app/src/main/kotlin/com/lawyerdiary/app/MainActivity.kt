package com.lawyerdiary.app

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

fun buildScheme(accent: Color, dark: Boolean): ColorScheme {
    val onAccent = if (accent.luminance() > 0.45f) Color(0xFF14161A) else Color.White
    return if (dark) {
        val surface = Color(0xFF171B22)
        darkColorScheme(
            primary = accent, onPrimary = onAccent,
            primaryContainer = accent.copy(alpha = 0.22f).compositeOver(surface), onPrimaryContainer = Color(0xFFEDEFF3),
            secondary = accent, background = Color(0xFF0E1116), onBackground = Color(0xFFE8EAED),
            surface = surface, onSurface = Color(0xFFE8EAED),
            surfaceVariant = Color(0xFF222833), onSurfaceVariant = Color(0xFFA9AFBA),
            outline = Color(0xFF353C49), error = Color(0xFFFF6B6B)
        )
    } else {
        lightColorScheme(
            primary = accent, onPrimary = onAccent,
            primaryContainer = accent.copy(alpha = 0.16f).compositeOver(Color.White), onPrimaryContainer = Color(0xFF1B1B1F),
            secondary = accent, background = Color(0xFFF6F7FA), onBackground = Color(0xFF1B1B1F),
            surface = Color.White, onSurface = Color(0xFF1B1B1F),
            surfaceVariant = Color(0xFFECEEF3), onSurfaceVariant = Color(0xFF555A64),
            outline = Color(0xFFD3D6DD), error = Color(0xFFB3261E)
        )
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val settings = remember { SettingsState(applicationContext) }
            val dark = when (settings.mode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
            val accent = ACCENTS[settings.accent.coerceIn(0, ACCENTS.size - 1)].second
            CompositionLocalProvider(
                LocalSettings provides settings,
                LocalLayoutDirection provides LayoutDirection.Rtl
            ) {
                MaterialTheme(colorScheme = buildScheme(accent, dark)) {
                    Surface(color = MaterialTheme.colorScheme.background) {
                        AskNotificationPermission()
                        AppRoot()
                    }
                }
            }
        }
    }
}

@Composable
private fun AskNotificationPermission() {
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) launcher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
}
