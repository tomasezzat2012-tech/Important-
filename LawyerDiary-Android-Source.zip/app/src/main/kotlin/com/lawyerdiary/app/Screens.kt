package com.lawyerdiary.app

import android.content.Context
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

fun authError(e: Throwable): String {
    if (e is FirebaseNetworkException) return "مفيش اتصال بالإنترنت."
    val code = (e as? FirebaseAuthException)?.errorCode ?: ""
    return when (code) {
        "ERROR_INVALID_EMAIL" -> "الإيميل مكتوب غلط."
        "ERROR_WRONG_PASSWORD", "ERROR_INVALID_CREDENTIAL", "ERROR_USER_NOT_FOUND" -> "الإيميل أو كلمة المرور غلط."
        "ERROR_EMAIL_ALREADY_IN_USE" -> "الإيميل ده مسجّل قبل كده."
        "ERROR_WEAK_PASSWORD" -> "كلمة المرور ضعيفة (6 أحرف على الأقل)."
        "ERROR_TOO_MANY_REQUESTS" -> "محاولات كتير، جرّب بعد شوية."
        else -> e.message ?: "حصل خطأ، جرّب تاني."
    }
}

@Composable
fun AppRoot() {
    val ctx = LocalContext.current
    var user by remember { mutableStateOf(Repo.auth.currentUser) }
    var crash by remember { mutableStateOf(ctx.getSharedPreferences("crash", Context.MODE_PRIVATE).getString("last", null)) }
    DisposableEffect(Unit) {
        val l = FirebaseAuth.AuthStateListener { user = it.currentUser }
        Repo.auth.addAuthStateListener(l)
        onDispose { Repo.auth.removeAuthStateListener(l) }
    }
    val c = crash
    if (c != null) CrashDialog(c) {
        ctx.getSharedPreferences("crash", Context.MODE_PRIVATE).edit().remove("last").apply()
        crash = null
    }
    val u = user
    if (u == null) AuthScreen() else ProfileGate(u)
}

@Composable
private fun CrashDialog(text: String, onClose: () -> Unit) {
    val clip = LocalClipboardManager.current
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("حصل خطأ في المرة اللي فاتت") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("انسخ الخطأ وابعته للمطوّر عشان يتصلح.", fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                Text(text.take(1200), fontSize = 10.sp)
            }
        },
        confirmButton = { TextButton(onClick = { clip.setText(AnnotatedString(text)); onClose() }) { Text("نسخ وإغلاق") } },
        dismissButton = { TextButton(onClick = onClose) { Text("إغلاق") } }
    )
}

@Composable
private fun ProfileGate(user: FirebaseUser) {
    var verified by remember(user.uid) { mutableStateOf(user.isEmailVerified) }
    if (AppConfig.REQUIRE_EMAIL_VERIFICATION && !verified) {
        VerifyScreen(user) { verified = true }
    } else {
        ProfileLoader(user)
    }
}

@Composable
private fun ProfileLoader(user: FirebaseUser) {
    var loaded by remember(user.uid) { mutableStateOf(false) }
    var profile by remember(user.uid) { mutableStateOf<Map<String, Any>?>(null) }
    var loadError by remember(user.uid) { mutableStateOf<String?>(null) }
    DisposableEffect(user.uid) {
        val reg = Repo.db.collection("users").document(user.uid).addSnapshotListener { s, e ->
            if (e != null) { loadError = e.message; loaded = true; return@addSnapshotListener }
            profile = s?.data
            loaded = true
        }
        onDispose { reg.remove() }
    }
    val p = profile
    when {
        !loaded -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
        loadError != null && p == null -> Column(
            Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally
        ) {
            Text("تعذر تحميل الحساب.\n$loadError", textAlign = TextAlign.Center)
            Spacer(Modifier.height(12.dp))
            Button(onClick = { Repo.auth.signOut() }) { Text("تسجيل الخروج") }
        }
        p == null -> CompleteProfileScreen(user)
        else -> MainScreen(user, p)
    }
}

@Composable
fun AuthScreen() {
    val scope = rememberCoroutineScope()
    var register by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var info by remember { mutableStateOf<String?>(null) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        Arrangement.Center, Alignment.CenterHorizontally
    ) {
        Logo(96.dp)
        Spacer(Modifier.height(14.dp))
        Text("مفكرة المحامي", fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text(if (register) "إنشاء حساب" else "تسجيل الدخول", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(22.dp))

        if (register) {
            OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("الاسم") })
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                phone, { phone = it.filter { c -> c.isDigit() || c == '+' } }, Modifier.fillMaxWidth(), singleLine = true,
                label = { Text("رقم التليفون") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
            )
            Spacer(Modifier.height(10.dp))
        }
        OutlinedTextField(
            email, { email = it.trim() }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("الإيميل") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)
        )
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            pass, { pass = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("كلمة المرور") },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
        )
        error?.let { Spacer(Modifier.height(8.dp)); Text(it, color = MaterialTheme.colorScheme.error, fontSize = 13.sp) }
        info?.let { Spacer(Modifier.height(8.dp)); Text(it, color = StGreen, fontSize = 13.sp) }
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = {
                error = null; info = null
                if (email.isBlank() || pass.length < 6) { error = "اكتب إيميل صحيح وكلمة مرور 6 أحرف على الأقل."; return@Button }
                if (register && (name.isBlank() || phone.length < 10)) { error = "اكتب الاسم ورقم تليفون صحيح."; return@Button }
                scope.launch {
                    busy = true
                    try {
                        if (register) {
                            val r = Repo.auth.createUserWithEmailAndPassword(email, pass).await()
                            val u = r.user
                            if (u != null) {
                                try { Repo.saveProfile(u.uid, name.trim(), phone, email) } catch (_: Exception) { }
                                try { u.sendEmailVerification().await() } catch (_: Exception) { }
                            }
                        } else {
                            Repo.auth.signInWithEmailAndPassword(email, pass).await()
                        }
                    } catch (e: Exception) { error = authError(e) }
                    busy = false
                }
            },
            enabled = !busy, modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text(if (register) "إنشاء الحساب" else "دخول", fontSize = 16.sp) }
        if (!register) {
            TextButton(onClick = {
                error = null; info = null
                if (email.isBlank()) { error = "اكتب الإيميل الأول."; return@TextButton }
                scope.launch {
                    try { Repo.auth.sendPasswordResetEmail(email).await(); info = "بعتنا رابط تغيير كلمة المرور على إيميلك." }
                    catch (e: Exception) { error = authError(e) }
                }
            }) { Text("نسيت كلمة المرور؟") }
        }
        TextButton(onClick = { register = !register; error = null; info = null }) {
            Text(if (register) "عندي حساب بالفعل" else "مستخدم جديد؟ أنشئ حساب")
        }
    }
}

@Composable
private fun VerifyScreen(user: FirebaseUser, onVerified: () -> Unit) {
    val scope = rememberCoroutineScope()
    var msg by remember { mutableStateOf<String?>(null) }
    var cooldown by remember { mutableStateOf(0) }

    // يتأكد كل 4 ثواني لوحده
    LaunchedEffect(user.uid) {
        while (true) {
            delay(4000)
            try { user.reload().await() } catch (_: Exception) { }
            if (user.isEmailVerified) { onVerified(); break }
        }
    }
    LaunchedEffect(cooldown) { if (cooldown > 0) { delay(1000); cooldown -= 1 } }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        Arrangement.Center, Alignment.CenterHorizontally
    ) {
        Logo(80.dp)
        Spacer(Modifier.height(16.dp))
        Text("أكّد الإيميل", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(
            "بعتنا رابط تأكيد على\n${user.email}\nافتح الرابط وبعدين ارجع هنا، وهتدخل تلقائي.\nلو مش لاقيه شوف مجلد Spam.",
            textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        msg?.let { Spacer(Modifier.height(8.dp)); Text(it, fontSize = 13.sp, color = MaterialTheme.colorScheme.primary) }
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = {
                scope.launch {
                    try { user.reload().await() } catch (_: Exception) { }
                    if (user.isEmailVerified) onVerified() else msg = "لسه ماتأكدش. افتح الرابط من الإيميل."
                }
            },
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text("أكدت الإيميل") }
        TextButton(
            onClick = {
                scope.launch {
                    try { user.sendEmailVerification().await(); msg = "اتبعت الرابط تاني."; cooldown = 60 }
                    catch (e: Exception) { msg = authError(e) }
                }
            },
            enabled = cooldown == 0
        ) { Text(if (cooldown > 0) "إعادة الإرسال بعد $cooldown ث" else "إعادة إرسال الرابط") }
        TextButton(onClick = { Repo.auth.signOut() }) { Text("تسجيل الخروج") }
    }
}

@Composable
private fun CompleteProfileScreen(user: FirebaseUser) {
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf(user.displayName ?: "") }
    var phone by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Text("كمّل بياناتك", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("الاسم") })
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(
            phone, { phone = it.filter { c -> c.isDigit() || c == '+' } }, Modifier.fillMaxWidth(), singleLine = true,
            label = { Text("رقم التليفون") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone)
        )
        error?.let { Spacer(Modifier.height(8.dp)); Text(it, color = MaterialTheme.colorScheme.error, fontSize = 13.sp) }
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = {
                if (name.isBlank() || phone.length < 10) { error = "اكتب الاسم ورقم تليفون صحيح."; return@Button }
                scope.launch {
                    busy = true
                    try { Repo.saveProfile(user.uid, name.trim(), phone, user.email ?: "") }
                    catch (e: Exception) { error = e.message }
                    busy = false
                }
            },
            enabled = !busy, modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text("حفظ ومتابعة") }
        TextButton(onClick = { Repo.auth.signOut() }) { Text("تسجيل الخروج") }
    }
}
