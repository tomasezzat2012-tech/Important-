package com.lawyerdiary.app

import com.google.firebase.firestore.DocumentSnapshot
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

const val ST_SCHEDULED = "scheduled"
const val ST_POSTPONED = "postponed"
const val ST_CANCELLED = "cancelled"

data class Session(
    val id: String = "",
    val title: String = "",
    val caseNo: String = "",
    val court: String = "",
    val notes: String = "",
    val at: Long = 0L,          // وقت الجلسة
    val wakeAt: Long = 0L,      // وقت الاستيقاظ
    val remindMin: Int = 60,    // التنبيه قبل الجلسة بكام دقيقة
    val alarmOn: Boolean = true,
    val status: String = ST_SCHEDULED,
    val postponedFrom: Long = 0L
) {
    fun toMap(): Map<String, Any> = mapOf(
        "title" to title, "caseNo" to caseNo, "court" to court, "notes" to notes,
        "at" to at, "wakeAt" to wakeAt, "remindMin" to remindMin, "alarmOn" to alarmOn,
        "status" to status, "postponedFrom" to postponedFrom
    )
}

fun DocumentSnapshot.toSession(): Session? {
    val d = data ?: return null
    return Session(
        id = id,
        title = d["title"] as? String ?: "",
        caseNo = d["caseNo"] as? String ?: "",
        court = d["court"] as? String ?: "",
        notes = d["notes"] as? String ?: "",
        at = (d["at"] as? Number)?.toLong() ?: 0L,
        wakeAt = (d["wakeAt"] as? Number)?.toLong() ?: 0L,
        remindMin = (d["remindMin"] as? Number)?.toInt() ?: 60,
        alarmOn = d["alarmOn"] as? Boolean ?: true,
        status = d["status"] as? String ?: ST_SCHEDULED,
        postponedFrom = (d["postponedFrom"] as? Number)?.toLong() ?: 0L
    )
}

object Fmt {
    private val ar = Locale("ar")
    fun date(ms: Long): String = SimpleDateFormat("EEEE d MMMM yyyy", ar).format(ms)
    fun shortDate(ms: Long): String = SimpleDateFormat("d MMMM yyyy", ar).format(ms)
    fun time(ms: Long): String = SimpleDateFormat("h:mm a", ar).format(ms)
    fun month(ms: Long): String = SimpleDateFormat("MMMM yyyy", ar).format(ms)
}

fun cal(ms: Long): Calendar = Calendar.getInstance().apply { timeInMillis = ms }

fun dayStart(ms: Long): Long {
    val c = cal(ms)
    c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
    return c.timeInMillis
}

/** تاريخ من dateMs + ساعة ودقيقة من timeMs */
fun withTime(dateMs: Long, timeMs: Long): Long {
    val t = cal(timeMs)
    val c = cal(dateMs)
    c.set(Calendar.HOUR_OF_DAY, t.get(Calendar.HOUR_OF_DAY))
    c.set(Calendar.MINUTE, t.get(Calendar.MINUTE))
    c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
    return c.timeInMillis
}

fun statusLabel(s: String) = when (s) {
    ST_CANCELLED -> "ملغاة"
    ST_POSTPONED -> "مؤجلة"
    else -> "قائمة"
}
