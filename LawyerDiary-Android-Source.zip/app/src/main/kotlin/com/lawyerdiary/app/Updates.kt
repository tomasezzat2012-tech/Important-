package com.lawyerdiary.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.content.pm.PackageInfoCompat
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class UpdateInfo(val code: Long, val name: String, val apk: String, val notes: String)

object Updates {
    /** ملف بيتولّد تلقائي مع كل Build ويتحط في آخر Release. */
    const val VERSION_URL = "https://github.com/tomasezzat2012-tech/Important-/releases/latest/download/version.json"
    const val FALLBACK_APK = "https://github.com/tomasezzat2012-tech/Important-/releases/latest/download/LawyerDiary.apk"

    fun currentCode(ctx: Context): Long = try {
        PackageInfoCompat.getLongVersionCode(ctx.packageManager.getPackageInfo(ctx.packageName, 0))
    } catch (_: Throwable) { 0L }

    fun currentName(ctx: Context): String = try {
        ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: ""
    } catch (_: Throwable) { "" }

    /** آخر إصدار منشور، أو null لو فشل الاتصال. */
    suspend fun fetch(): UpdateInfo? = withContext(Dispatchers.IO) {
        try {
            val c = URL(VERSION_URL).openConnection() as HttpURLConnection
            c.connectTimeout = 10_000
            c.readTimeout = 10_000
            c.instanceFollowRedirects = true
            c.setRequestProperty("Cache-Control", "no-cache")
            if (c.responseCode != 200) { c.disconnect(); return@withContext null }
            val text = c.inputStream.bufferedReader().use { it.readText() }
            c.disconnect()
            val o = JSONObject(text)
            UpdateInfo(
                code = o.optLong("versionCode", 0L),
                name = o.optString("versionName", ""),
                apk = o.optString("apk", FALLBACK_APK).ifBlank { FALLBACK_APK },
                notes = o.optString("notes", "")
            )
        } catch (_: Throwable) { null }
    }

    /** فحص تلقائي كل 4 ساعات عند فتح التطبيق. بيرجّع الإصدار الجديد لو موجود. */
    suspend fun autoCheck(ctx: Context): UpdateInfo? {
        val p = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
        val last = p.getLong("lastUpdateCheck", 0L)
        if (System.currentTimeMillis() - last < 4 * 3_600_000L) return null
        val info = fetch() ?: return null
        p.edit().putLong("lastUpdateCheck", System.currentTimeMillis()).apply()
        return if (info.code > currentCode(ctx)) info else null
    }

    /** فحص في الخلفية كل 4 ساعات (حتى والتطبيق مقفول) وإشعار لو فيه تحديث. */
    fun schedule(ctx: Context) {
        try {
            val req = PeriodicWorkRequestBuilder<UpdateWorker>(4, TimeUnit.HOURS)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
            WorkManager.getInstance(ctx).enqueueUniquePeriodicWork("update_check", ExistingPeriodicWorkPolicy.KEEP, req)
        } catch (_: Throwable) { }
    }
}

class UpdateWorker(private val ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        try {
            val info = Updates.fetch() ?: return Result.success()
            if (info.code <= Updates.currentCode(ctx)) return Result.success()
            val prefs = ctx.getSharedPreferences("settings", Context.MODE_PRIVATE)
            if (prefs.getLong("notifiedUpdate", 0L) >= info.code) return Result.success() // اتبلّغ عنه قبل كده
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) return Result.success()

            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= 26) {
                nm.createNotificationChannel(NotificationChannel("updates", "التحديثات", NotificationManager.IMPORTANCE_DEFAULT))
            }
            val open = PendingIntent.getActivity(
                ctx, 7, Intent(Intent.ACTION_VIEW, Uri.parse(info.apk)),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val text = if (info.notes.isBlank()) "اضغط لتحميل أحدث نسخة." else info.notes
            val n = NotificationCompat.Builder(ctx, "updates")
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("تحديث جديد لمفكرة المحامي ${info.name}")
                .setContentText(text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                .setContentIntent(open)
                .setAutoCancel(true)
                .build()
            NotificationManagerCompat.from(ctx).notify(2001, n)
            prefs.edit().putLong("notifiedUpdate", info.code).apply()
        } catch (_: Throwable) { }
        return Result.success()
    }
}
