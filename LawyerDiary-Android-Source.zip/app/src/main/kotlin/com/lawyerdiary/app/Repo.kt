package com.lawyerdiary.app

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.CollectionReference
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

object Repo {
    val auth: FirebaseAuth get() = FirebaseAuth.getInstance()
    val db: FirebaseFirestore get() = FirebaseFirestore.getInstance()

    fun sessions(uid: String): CollectionReference =
        db.collection("users").document(uid).collection("sessions")

    suspend fun saveProfile(uid: String, name: String, phone: String, email: String) {
        db.collection("users").document(uid).set(
            mapOf("name" to name, "phone" to phone, "email" to email, "createdAt" to System.currentTimeMillis())
        ).await()
    }

    suspend fun saveSession(uid: String, s: Session) {
        val col = sessions(uid)
        val ref = if (s.id.isEmpty()) col.document() else col.document(s.id)
        ref.set(s.toMap()).await()
    }

    suspend fun deleteSession(uid: String, id: String) {
        sessions(uid).document(id).delete().await()
    }
}
