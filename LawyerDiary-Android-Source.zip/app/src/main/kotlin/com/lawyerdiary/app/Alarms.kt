package com.lawyerdiary.app

import android.Manifest
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject

data class AlarmEntry(val id: String, val type: Int, val at: Long, val title: String, val text: String)

object Alarms {
    const val ACTION = "com.lawyerdiary.app.ALARM"
    const val ACTION_STOP = "com.lawyerdiary.app.ALARM_STOP"
    const val CHANNEL = "alarm_v1"
    private const val PREF = "alarms"

    private fun code(id: String, type: Int): Int = (id.hashCode() and 0x3fffffff) * 2 + type

    private fun pending(ctx: Context, e: AlarmEntry, create: Boolean): PendingIntent? {
        val i = Intent(ctx, AlarmReceiver::class.java).setAction(ACTION)
            .putExtra("title", e.title).putExtra("text", e.text).putExtra("nid", code(e.id, e.type))
        val flags = (if (create) PendingIntent.FLAG_UPDATE_CURRENT else PendingIntent.FLAG_NO_CREATE) or PendingIntent.FLAG_IMMUTABLE
        return PendingIntent.getBroadcast(ctx, code(e.id, e.type), i, flags)
    }

    private fun set(ctx: Context, am: AlarmManager, e: AlarmEntry) {
        val show = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val pi = pending(ctx, e, true) ?: return
        am.setAlarmClock(AlarmManager.AlarmClockInfo(e.at, show), pi)
    }

    private fun cancel(ctx: Context, am: AlarmManager, e: AlarmEntry) {
        val pi = pending(ctx, e, false) ?: return
        am.cancel(pi); pi.cancel()
    }

    fun load(ctx: Context): List<AlarmEntry> {
        val raw = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("list", "[]") ?: "[]"
        val out = ArrayList<AlarmEntry>()
        try {
            val a = JSONArray(raw)
            for (n in 0 until a.length()) {
                val o = a.getJSONObject(n)
                out.add(AlarmEntry(o.getString("id"), o.getInt("type"), o.getLong("at"), o.getString("title"), o.getString("text")))
            }
        } catch (_: Exception) { }
        return out
    }

    private fun save(ctx: Context, list: List<AlarmEntry>) {
        val a = JSONArray()
        list.forEach {
            a.put(JSONObject().put("id", it.id).put("type", it.type).put("at", it.at).put("title", it.title).put("text", it.text))
        }
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString("list", a.toString()).apply()
    }

    /** يعيد ضبط كل المنبهات حسب الجلسات الحالية (يلغي القديم ويضبط الجديد). */
    fun sync(ctx: Context, sessions: List<Session>) {
        try { syncInner(ctx, sessions) } catch (_: Throwable) { }
    }

    private fun syncInner(ctx: Context, sessions: List<Session>) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        load(ctx).forEach { e -> try { cancel(ctx, am, e) } catch (_: Throwable) { } }
        val now = System.currentTimeMillis()
        val list = ArrayList<AlarmEntry>()
        for (s in sessions) {
            if (!s.alarmOn || s.status == ST_CANCELLED) continue
            val base = if (s.type.isNotBlank()) "${s.title} (${s.type})" else s.title
            val what = if (s.court.isNotBlank()) "$base - ${s.court}" else base
            if (s.wakeAt > now) {
                list.add(AlarmEntry(s.id, 0, s.wakeAt, "⏰ وقت الاستيقاظ",
                    "عندك جلسة $what الساعة ${Fmt.time(s.at)}"))
            }
            val r = s.at - s.remindMin * 60_000L
            if (r > now) {
                list.add(AlarmEntry(s.id, 1, r, "⚖️ جلسة قريبة",
                    "$what - الساعة ${Fmt.time(s.at)} (${Fmt.shortDate(s.at)})"))
            }
        }
        val ok = ArrayList<AlarmEntry>()
        list.forEach { e -> try { set(ctx, am, e); ok.add(e) } catch (_: Throwable) { } }
        save(ctx, ok)
    }

    fun restore(ctx: Context) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val now = System.currentTimeMillis()
        load(ctx).filter { it.at > now }.forEach { e -> try { set(ctx, am, e) } catch (_: Throwable) { } }
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        try { handle(ctx, intent) } catch (_: Throwable) { }
    }

    private fun handle(ctx: Context, intent: Intent) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val nid = intent.getIntExtra("nid", 1)
        if (intent.action == Alarms.ACTION_STOP) { nm.cancel(nid); return }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return

        val sound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(Alarms.CHANNEL, "منبهات الجلسات", NotificationManager.IMPORTANCE_HIGH)
            ch.setSound(
                sound,
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            )
            ch.enableVibration(true)
            ch.vibrationPattern = longArrayOf(0, 700, 400, 700, 400, 700)
            ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            nm.createNotificationChannel(ch)
        }
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getBroadcast(
            ctx, nid, Intent(ctx, AlarmReceiver::class.java).setAction(Alarms.ACTION_STOP).putExtra("nid", nid),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val title = intent.getStringExtra("title") ?: "مفكرة المحامي"
        val text = intent.getStringExtra("text") ?: ""
        val b = NotificationCompat.Builder(ctx, Alarms.CHANNEL)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setContentIntent(open)
            .setAutoCancel(true)
            .addAction(0, "إيقاف", stop)
        if (Build.VERSION.SDK_INT < 26) {
            b.setSound(sound, AudioManager.STREAM_ALARM).setVibrate(longArrayOf(0, 700, 400, 700))
        }
        val n = b.build()
        n.flags = n.flags or Notification.FLAG_INSISTENT   // يكرر الصوت لحد ما توقفه
        nm.notify(nid, n)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        Alarms.restore(ctx)
    }
}
