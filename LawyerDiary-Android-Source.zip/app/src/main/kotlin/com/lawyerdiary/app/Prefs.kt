package com.lawyerdiary.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

object AppConfig {
    /** true = لازم المستخدم يأكد الإيميل (رابط بيوصله على Gmail) قبل ما يدخل. */
    const val REQUIRE_EMAIL_VERIFICATION = true
}

val ACCENTS: List<Pair<String, Color>> = listOf(
    "ذهبي" to Color(0xFFC9A24B),
    "أزرق" to Color(0xFF3B82F6),
    "زمردي" to Color(0xFF10B981),
    "بنفسجي" to Color(0xFF8B5CF6),
    "وردي" to Color(0xFFEC4899),
    "برتقالي" to Color(0xFFF97316),
    "سماوي" to Color(0xFF06B6D4)
)

class SettingsState(ctx: Context) {
    private val p = ctx.applicationContext.getSharedPreferences("settings", Context.MODE_PRIVATE)

    var mode by mutableStateOf(p.getInt("mode", 0))      // 0 تلقائي، 1 فاتح، 2 داكن
        private set
    var accent by mutableStateOf(p.getInt("accent", 0))
        private set
    var remind by mutableStateOf(p.getInt("remind", 60)) // دقائق قبل الجلسة
        private set
    var wakeHours by mutableStateOf(p.getInt("wake", 3)) // ساعات الاستيقاظ قبل الجلسة
        private set

    fun setMode(v: Int) { mode = v; p.edit().putInt("mode", v).apply() }
    fun setAccent(v: Int) { accent = v; p.edit().putInt("accent", v).apply() }
    fun setRemind(v: Int) { remind = v; p.edit().putInt("remind", v).apply() }
    fun setWakeHours(v: Int) { wakeHours = v; p.edit().putInt("wake", v).apply() }
}

val LocalSettings = staticCompositionLocalOf<SettingsState> { error("SettingsState not provided") }
