package com.lawyerdiary.app

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** شعار التطبيق (نفس أيقونة الـ launcher). */
@Composable
fun Logo(size: Dp = 84.dp) {
    Image(
        painter = painterResource(R.drawable.ic_launcher),
        contentDescription = "الشعار",
        modifier = Modifier.size(size).clip(RoundedCornerShape(size * 0.24f))
    )
}

@Composable
fun AppCard(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Card(
        modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) { Column(Modifier.padding(14.dp)) { content() } }
}

@Composable
fun ChipBtn(label: String, selected: Boolean, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(
        Modifier.clip(RoundedCornerShape(20.dp))
            .background(if (selected) cs.primary else cs.surfaceVariant)
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 8.dp),
        Alignment.Center
    ) {
        Text(label, fontSize = 13.sp, color = if (selected) cs.onPrimary else cs.onSurfaceVariant)
    }
}

@Composable
fun Pill(text: String, color: Color) {
    Text(
        text, fontSize = 11.sp, color = Color.White,
        modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(color).padding(horizontal = 9.dp, vertical = 3.dp)
    )
}

val StGreen = Color(0xFF2E9E5B)
val StAmber = Color(0xFFD98E00)
val StRed = Color(0xFFD64545)

fun statusColor(s: String): Color = when (s) {
    ST_CANCELLED -> StRed
    ST_POSTPONED -> StAmber
    else -> StGreen
}
