plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("com.google.gms.google-services")
}

val vc: Int = (project.findProperty("vc") as String?)?.toIntOrNull() ?: 2
val vn: String = (project.findProperty("vn") as String?) ?: "1.1"

android {
    namespace = "com.lawyerdiary.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.lawyerdiary.app"
        minSdk = 23
        targetSdk = 34
        versionCode = vc
        versionName = vn
    }

    signingConfigs {
        create("main") {
            storeFile = file("lawyer-release.keystore")
            storePassword = "lawyer123456"
            keyAlias = "lawyer"
            keyPassword = "lawyer123456"
        }
    }
    buildTypes {
        debug { signingConfig = signingConfigs.getByName("main") }
        release {
            signingConfig = signingConfigs.getByName("main")
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.animation:animation")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.work:work-runtime-ktx:2.9.0")

    implementation(platform("com.google.firebase:firebase-bom:33.1.2"))
    implementation("com.google.firebase:firebase-auth")
    implementation("com.google.firebase:firebase-firestore")
    implementation("androidx.compose.material:material-icons-core")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.8.1")
}
